class Helper{
  
     print(count,div,up,URL){

        const data=URL+" এটা সরকারি ওয়েবসাইট অ্যাড্রেস "+up+",  "+div+",  "+count+" এর ।";


     console.log();   console.log(data);


     }
}

export {Helper}