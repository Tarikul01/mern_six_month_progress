const postLogin=require("./postLogin");
const postRegister=require("./postRegister");
const passwordUpdate=require("./passwordUpdate");

exports.controllers={
    postLogin,
    postRegister,
    passwordUpdate
    
}