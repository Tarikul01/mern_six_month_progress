# React CRUD app using redux toolkit...

Live Link: [https://rdx-crud-app.netlify.app/](https://rdx-crud-app.netlify.app/)

![Preview](./src/assets/images/preview.png)
