import React from "react";

const Home = () => {
  return (
    <>
      <h1
        className="text-center"
        style={{ letterSpacing: "4px", marginTop: "200px" }}
      >
        React CRUD app using Redux Toolkit
      </h1>
    </>
  );
};

export default Home;
