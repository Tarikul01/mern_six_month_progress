import React from "react";

const Error = () => {
  return (
    <div>
      <h1>Error page</h1>
    </div>
  );
};

export default Error;
