import React from "react";

const Footer = () => {
  return (
    <div className="bg-dark p-3 text-light">
      <span className="d-block text-center">
        Copyright by Md Tarikul islam @2023
      </span>
    </div>
  );
};

export default Footer;
